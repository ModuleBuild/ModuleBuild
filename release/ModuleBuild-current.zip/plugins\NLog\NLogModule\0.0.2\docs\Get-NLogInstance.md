﻿---
external help file: NLogModule-help.xml
online version: 
schema: 2.0.0
---

# Get-NLogInstance

## SYNOPSIS
Gets the current nlog instance for the module

## SYNTAX

```
Get-NLogInstance
```

## DESCRIPTION
Gets the current nlog instance for the module

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
$myCurrentNlog = Get-NLogInstance
```

## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS

